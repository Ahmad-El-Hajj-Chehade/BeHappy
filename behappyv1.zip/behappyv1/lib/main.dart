import 'package:behappyv1/homepage.dart';
import 'package:behappyv1/signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

Future<void> main() async {
  // Ensure that plugin services are initialized so that `availableCameras()`
// can be called before `runApp()`
  WidgetsFlutterBinding.ensureInitialized();

// Obtain a list of the available cameras on the device.
  final cameras = await availableCameras();

// Get a specific camera from the list of available cameras.
  final firstCamera = cameras.first;
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MaterialApp(home:SignInStateless()));
}

class SignInStateless extends StatelessWidget{
  @override
  Widget build(BuildContext context) => Scaffold(
      body:StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot){
          if(snapshot.hasData){
            return HomePage();
          }

          else{

            return SignIn();

          }

        },
      )
  );

}

class SignIn extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => SignInState();

}
class SignInState extends State<SignIn>{
  signup(){
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context){
      return SignUp();
    }));
  }
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: AppBar(
       title: Text('BeHappy'),
       centerTitle: true,
     ),
     body: Column(
       mainAxisAlignment: MainAxisAlignment.center,
       children: [
         Text('Email'),
         Padding(padding: EdgeInsets.fromLTRB(400, 0, 400, 30), child: TextField(controller: emailcontroller)),
         Text('Password'),
         Padding(padding: EdgeInsets.fromLTRB(400, 0, 400, 0), child: TextField(controller: passwordcontroller, obscureText: true)),
         Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [

             ElevatedButton(onPressed: () async {
               try{
                 await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailcontroller.text, password: passwordcontroller.text);
               }on FirebaseAuthException catch(e){
                 ScaffoldMessenger.of(context).showSnackBar(
                   const SnackBar(
                     content:Text(
                         "Email or Password invalid"),
                   ),
                 );

                 print(e.message);

               }

             }, child: Text('SignIn'),style:ElevatedButton.styleFrom(
               primary: Colors.green)),

             ElevatedButton(onPressed: signup, child: Text('SignUp')),
           ],
         )
       ],
     ),
   );
  }

}