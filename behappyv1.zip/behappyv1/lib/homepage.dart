import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class HomePage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => HomePageState();
}

class HomePageState extends State<HomePage>{

  String imageUrl = '';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Scaffold(
        body: SafeArea(
          child: Text('Hi'),
        ),
        bottomNavigationBar: Container(
          height: 60,
          color: Colors.black12,
          child: InkWell(
            onTap: () async{
              ImagePicker imagePicker = ImagePicker();
              XFile? file = await imagePicker.pickImage(source: ImageSource.gallery);
              print('${file?.path}');

              if(file== null)return;
              String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
              //upload image to firebase storage

              Reference referenceRoot = FirebaseStorage.instance.ref();
              Reference referenceDirImages = referenceRoot.child('images');

              Reference referenceImageToUpload = referenceDirImages.child(uniqueFileName);
              try {
               await referenceImageToUpload.putFile(File(file!.path));
              imageUrl = await referenceImageToUpload.getDownloadURL();
              }catch(error){
                  print(error.toString());
              }
            },
            child: Padding(
              padding: EdgeInsets.only(top: 8.0),
              child: Column(
                children: <Widget>[
                  Icon(
                    Icons.camera,
                    color: Theme.of(context).accentColor,
                  ),
                  Text('Upload'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

}


