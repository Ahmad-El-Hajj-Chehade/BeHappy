import 'package:behappyv1/homepage.dart';
import 'package:behappyv1/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'main.dart';



class SignUpStateless extends StatelessWidget{
  @override
  Widget build(BuildContext context) => Scaffold(
      body:StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot){
          if(snapshot.hasData){
            return HomePage();
          }

          else{

            return SignUp();

          }

        },
      )
  );

}

class SignUp extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => SignUpState();

}
class SignUpState extends State<SignUp>{
  signin(){
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context){
      return SignIn();
    }));
  }
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text('BeHappy'),
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Email'),
          Padding(padding: EdgeInsets.fromLTRB(400, 0, 400, 30), child: TextField(controller: emailcontroller)),
          Text('Password'),
          Padding(padding: EdgeInsets.fromLTRB(400, 0, 400, 0), child: TextField(controller: passwordcontroller, obscureText: true)),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              ElevatedButton(onPressed: () async {
                try{
                  await FirebaseAuth.instance.createUserWithEmailAndPassword(email: emailcontroller.text, password: passwordcontroller.text);
                }on FirebaseAuthException catch(e){
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content:Text(
                          "Email or Password invalid"),
                    ),
                  );

                  print(e.message);

                }

              }, child: Text('SignUp'), style:ElevatedButton.styleFrom(
                primary: Colors.green,
              )),

              ElevatedButton(onPressed: signin, child: Text('Sign In')),
              ],
          )
        ],
      ),
    );
  }

}